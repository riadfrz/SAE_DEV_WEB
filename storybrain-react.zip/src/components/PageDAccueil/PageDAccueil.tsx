import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { BgIcon } from './BgIcon';
import { Carte1 } from './Carte1/Carte1';
import { Carte9 } from './Carte9/Carte9';
import { FacebookIcon } from './FacebookIcon';
import { GroupIcon } from './GroupIcon';
import { LinkedIn_StyleSolidCircleShape } from './LinkedIn_StyleSolidCircleShape/LinkedIn_StyleSolidCircleShape';
import { Oval2Copy6Icon } from './Oval2Copy6Icon';
import { Oval2Icon } from './Oval2Icon';
import classes from './PageDAccueil.module.css';
import { TwitterIcon } from './TwitterIcon';
import { VectorIcon } from './VectorIcon';
import { YouTube_StyleSolidCircleShapeT } from './YouTube_StyleSolidCircleShapeT/YouTube_StyleSolidCircleShapeT';

interface Props {
  className?: string;
}
/* @figmaId 1:3 */
export const PageDAccueil: FC<Props> = memo(function PageDAccueil(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.vertFond}></div>
      <div className={classes.vertFond3}></div>
      <div className={classes.vertFond4}></div>
      <button className={classes.button}>
        <div className={classes.vOIRPLUS}>VOIR PLUS</div>
      </button>
      <div className={classes.maskCopy}></div>
      <div className={classes.rectangle3Copy40}></div>
      <div className={classes.sOCIALMEDIA}>Réseau sociaux</div>
      <YouTube_StyleSolidCircleShapeT
        className={classes.youTube}
        classes={{ group: classes.group }}
        swap={{
          group: (
            <div className={classes.group}>
              <GroupIcon className={classes.icon} />
            </div>
          ),
        }}
      />
      <LinkedIn_StyleSolidCircleShape
        className={classes.linkedIn}
        swap={{
          vector: <VectorIcon className={classes.icon2} />,
        }}
      />
      <div className={classes.facebook}>
        <FacebookIcon className={classes.icon3} />
      </div>
      <div className={classes.twitter}>
        <TwitterIcon className={classes.icon4} />
      </div>
      <div className={classes.infosPratiques}>
        <div className={classes.textBlock}>Infos pratiques</div>
        <div className={classes.textBlock2}>
          <p className={classes.labelWrapper}>
            <span className={classes.label}>Email</span>
          </p>
        </div>
        <div className={classes.textBlock3}>Adresse</div>
        <div className={classes.textBlock4}> Numéro</div>
      </div>
      <div className={classes.onTheBlogPopular}>
        <div className={classes.textBlock5}>Liens utiles</div>
        <div className={classes.textBlock6}>
          <p className={classes.labelWrapper2}>
            <span className={classes.label2}>Communauté</span>
          </p>
        </div>
        <div className={classes.textBlock7}>Domaines d’actions</div>
        <div className={classes.textBlock8}>Les grands projets</div>
        <div className={classes.textBlock9}>Les équipements</div>
      </div>
      <div className={classes.learnUXDesignWord}>
        <div className={classes.textBlock10}>Learn</div>
        <div className={classes.textBlock11}>
          <p className={classes.labelWrapper3}>
            <span className={classes.label3}>UX Design</span>
          </p>
        </div>
        <div className={classes.textBlock12}>Wordpress</div>
        <div className={classes.textBlock13}>PHP</div>
      </div>
      <div className={classes.logo}></div>
      <button className={classes.button2}>
        <div className={classes.pLusDInfos}>PLus d’infos</div>
      </button>
      <div className={classes.morlaix}>Morlaix</div>
      <div className={classes.carteDesCommunes}>Carte des communes</div>
      <div className={classes.frame2}>
        <div className={classes.frame1}>
          <Carte9 />
          <div className={classes.carte7}>
            <div className={classes.rectangle4}></div>
            <div className={classes.rectangle3Copy37}></div>
            <div className={classes.designbetter_website_book_asse}></div>
            <div className={classes.sousTitre}>
              <div className={classes.textBlock14}>
                Achetez un vélo électrique, en 2023, Morlaix Communauté vous accompagne !
              </div>
              <div className={classes.textBlock15}>
                <p></p>
              </div>
            </div>
            <div className={classes.titre}>Prime achat Vélo à Assistance Electrique (VAE) 2023</div>
            <div className={classes.date}></div>
          </div>
          <div className={classes.carte5}>
            <div className={classes.rectangle42}></div>
            <div className={classes.rectangle3Copy372}></div>
            <div className={classes.designbetter_website_book_asse2}></div>
            <div className={classes.sousTitre2}>
              <div className={classes.textBlock16}>
                Achetez un vélo électrique, en 2023, Morlaix Communauté vous accompagne !
              </div>
              <div className={classes.textBlock17}>
                <p></p>
              </div>
            </div>
            <div className={classes.titre2}>Prime achat Vélo à Assistance Electrique (VAE) 2023</div>
            <div className={classes.date2}></div>
          </div>
          <div className={classes.carte9}>
            <div className={classes.rectangle43}></div>
            <div className={classes.rectangle3Copy373}></div>
            <div className={classes.designbetter_website_book_asse3}></div>
            <div className={classes.sousTitre3}>
              <div className={classes.textBlock18}>
                Achetez un vélo électrique, en 2023, Morlaix Communauté vous accompagne !
              </div>
              <div className={classes.textBlock19}>
                <p></p>
              </div>
            </div>
            <div className={classes.titre3}>Prime achat Vélo à Assistance Electrique (VAE) 2023</div>
            <div className={classes.date3}></div>
          </div>
          <div className={classes.carte72}>
            <div className={classes.rectangle44}></div>
            <div className={classes.rectangle3Copy374}></div>
            <div className={classes.designbetter_website_book_asse4}></div>
            <div className={classes.sousTitre4}>
              <div className={classes.textBlock20}>
                Achetez un vélo électrique, en 2023, Morlaix Communauté vous accompagne !
              </div>
              <div className={classes.textBlock21}>
                <p></p>
              </div>
            </div>
            <div className={classes.titre4}>Prime achat Vélo à Assistance Electrique (VAE) 2023</div>
            <div className={classes.date4}></div>
          </div>
          <div className={classes.carte10}>
            <div className={classes.rectangle45}></div>
            <div className={classes.rectangle3Copy375}></div>
            <div className={classes.designbetter_website_book_asse5}></div>
            <div className={classes.sousTitre5}>
              <div className={classes.textBlock22}>
                Achetez un vélo électrique, en 2023, Morlaix Communauté vous accompagne !
              </div>
              <div className={classes.textBlock23}>
                <p></p>
              </div>
            </div>
            <div className={classes.titre5}>Prime achat Vélo à Assistance Electrique (VAE) 2023</div>
            <div className={classes.date5}></div>
          </div>
        </div>
      </div>
      <div className={classes.event3}></div>
      <div className={classes.ombre3}></div>
      <div className={classes.event2}></div>
      <div className={classes.ombre4}></div>
      <div className={classes.event1}></div>
      <div className={classes.oval2}>
        <Oval2Icon className={classes.icon5} />
      </div>
      <div className={classes.leftArrow}></div>
      <div className={classes.oval2Copy6}>
        <Oval2Copy6Icon className={classes.icon6} />
      </div>
      <div className={classes.rightArrow}></div>
      <div className={classes.evenements}>Évènements</div>
      <div className={classes.carte3}>
        <div className={classes.rectangle46}></div>
        <div className={classes.rectangle3Copy376}></div>
        <div className={classes.designbetter_website_book_asse6}></div>
        <div className={classes.sousTitre6}>La nouvelle session du défi des foyers presque zéro déchet approche...</div>
        <div className={classes.titre6}>Le défi des foyers presque zéro déchet : prêt à relever le défi ?</div>
      </div>
      <div className={classes.carte2}>
        <div className={classes.rectangle47}></div>
        <div className={classes.rectangle3Copy377}></div>
        <div className={classes.designbetter_website_book_asse7}></div>
        <div className={classes.sousTitre7}>
          <div className={classes.textBlock24}>
            Achetez un vélo électrique, en 2023, Morlaix Communauté vous accompagne !
          </div>
          <div className={classes.textBlock25}>
            <p></p>
          </div>
        </div>
        <div className={classes.titre7}>Prime achat Vélo à Assistance Electrique (VAE) 2023</div>
      </div>
      <Carte1 />
      <button className={classes.button3}>
        <div className={classes.vOIRPLUS2}>VOIR PLUS</div>
      </button>
      <div className={classes.fond}></div>
      <div className={classes.bIENVENUEAMORLAIXCOMMUNAUTE}>BIENVENUE A MORLAIX COMMUNAUTÉ</div>
      <div className={classes.decouvrezLActualite}>Découvrez l’actualité !</div>
      <div className={classes.agenda}>Agenda</div>
      <div className={classes.rectangle1}></div>
      <div className={classes.logo2}></div>
      <div className={classes.communaute}>Communauté</div>
      <div className={classes.domainesDActions}>Domaines d’actions</div>
      <div className={classes.lesGrandsProjets}>Les grands projets</div>
      <div className={classes.lesEquipements}>Les équipements</div>
      <div className={classes.line1}></div>
      <div className={classes.line2}></div>
      <div className={classes.carre}></div>
      <div className={classes.bG}>
        <BgIcon className={classes.icon7} />
      </div>
      <div className={classes.typeSomething}>Rechercher...</div>
      <div className={classes.magnifyingGlass}></div>
      <div className={classes.image1}></div>
      <div className={classes.mentionsLegales20232024}>Mentions Légales 2023-2024</div>
    </div>
  );
});
