import { memo, SVGProps } from 'react';

const FacebookIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 42 38' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={21.1599} cy={18.8613} rx={20.2677} ry={18.8613} fill='#FF5480' />
    <path
      d='M33.313 19.5997H25.3144V31.9295H13.1959V19.5997H7.43227V15.2665H13.1959V12.4624C13.1959 10.4572 15.4596 7.31726 25.4223 7.31726L34.399 7.33306V11.5392H27.8858C26.8175 11.5392 25.3152 11.7638 25.3152 12.7203V15.2705H34.3718L33.313 19.5997Z'
      fill='white'
    />
  </svg>
);
const Memo = memo(FacebookIcon);
export { Memo as FacebookIcon };
