import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import classes from './Carte1.module.css';

interface Props {
  className?: string;
}
/* @figmaId 6:27 */
export const Carte1: FC<Props> = memo(function Carte1(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.rectangle4}></div>
      <div className={classes.rectangle3Copy37}></div>
      <div className={classes.designbetter_website_book_asse}></div>
      <div className={classes.sousTitre}>
        <div className={classes.textBlock}>
          Avec son nouveau journal Grands Projets, Morlaix Communauté informe les habitants au plus près...
        </div>
        <div className={classes.textBlock2}>
          <p></p>
        </div>
      </div>
      <div className={classes.titre}>Festival Panoramas #26, le quartier de la Manu s&#39;adapte !</div>
    </div>
  );
});
